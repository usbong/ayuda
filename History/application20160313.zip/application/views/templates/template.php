<?php 
$this->load->view('includes/header');
$this->load->view($content);
$this->load->view('includes/footer');
?>